# SERVER SERVER SERVER SERVER SERVER SERVER SERVER SERVER SERVER SERVER SERVER SERVER SERVER SERVER SERVER SERVER SERVER

server<-function(input, output,session) {
  #_________________________create map consisting of several layers and customization___________________
  output$map1 <- renderLeaflet({  #initiate map
    leaflet(options = leafletOptions(minZoom = 4.5)) %>%
      addProviderTiles(providers$CartoDB.PositronNoLabels) %>% #base map, can be changed
      setView(45.4064,15.0527, zoom = 8)
    # setMaxBounds( lng1 = -66.9
    #               , lat1 = 37
    #               , lng2 = -66.1
    #               , lat2 = 37.8 )
  })
  
  #"observe" inputs to define variables for map colors, titles, legends and subset district data
  observe({
    VARIA <- input$variable1
    #YlOrRd #YlGnBu #RdPu #OrRd #Greys #Greens #viridis #magma
    if (VARIA == "exchange_rates") {
      dataM<-Rshp[,c(1,5,7,8,10,26)] #subset exchange rate col
      mypal<-colorNumeric( palette="OrRd", domain=dataM@data[,6], na.color = "#9C9D9F")
      pLa<-"Exchange Rate "
      en<-" "
      unitA="$"
    }
    if (VARIA == "petrol") {
      dataM<-Rshp[,c(1,5,7,8,10,18)] #subset exchange rate col
      mypal<-colorNumeric( palette="YlOrRd", domain=dataM@data[,6], na.color = "#9C9D9F")
      pLa<-"Petrol Price "
      en<-" "
      unitA="$"
    }
    if (VARIA == "diesel") {
      dataM<-Rshp[,c(1,5,7,8,10,19)] #subset exchange rate col
      mypal<-colorNumeric( palette="magma", domain=dataM@data[,6], na.color = "#9C9D9F")
      pLa<-"Diesel Price "
      en<-" "
      unitA="$"
    }
    if (VARIA == "bottled_water") {
      dataM<-Rshp[,c(1,5,7,8,10,20)] #subset exchange rate col
      mypal<-colorNumeric( palette="Reds", domain=dataM@data[,6], na.color = "#9C9D9F")
      pLa<-"Bottled Water Price"
      en<-" "
      unitA="$"
    }
    if (VARIA == "treated_water") {
      dataM<-Rshp[,c(1,5,7,8,10,21)] #subset exchange rate col
      mypal<-colorNumeric( palette="YlGnBu", domain=dataM@data[,6], na.color = "#9C9D9F")
      pLa<-"Treated Water Price"
      en<-" "
      unitA="$"
    }
    if (VARIA == "soap") {
      dataM<-Rshp[,c(1,5,7,8,10,22)] #subset exchange rate col
      mypal<-colorNumeric( palette="viridis", domain=dataM@data[,6], na.color = "#9C9D9F")
      pLa<-"Soap Price"
      en<-" "
      unitA="$"
    }
    if (VARIA == "laundry_powder") {
      dataM<-Rshp[,c(1,5,7,8,10,23)] #subset exchange rate col
      mypal<-colorNumeric( palette="Greens", domain=dataM@data[,6], na.color = "#9C9D9F")
      pLa<-"Laundry Powder Price"
      en<-" "
      unitA="$" 
    }
    if (VARIA == "sanitary_napkins") {
      dataM<-Rshp[,c(1,5,7,8,10,24)] #subset exchange rate col
      mypal<-colorNumeric( palette="BuPu", domain=dataM@data[,6], na.color = "#9C9D9F")
      pLa<-"Sanitary Napkin Price"
      en<-" "
      unitA="$"
    }
    if (VARIA == "cost_cubic_meter") {
      dataM<-Rshp[,c(1,5,7,8,10,25)] #subset exchange rate col
      mypal<-colorNumeric( palette="RdPu", domain=dataM@data[,6], na.color = "#9C9D9F")
      pLa<-"??????"
      en<-" "
      unitA="$"
    }
     
    #leaflet map proxy updates created map to reflect obeserved changes
    map1<-leafletProxy("map1") %>%
      clearShapes() %>% #clear polygons, so new ones can be added
      clearControls()%>% #reset zoom etc
      
      
      addLabelOnlyMarkers(centroids, #ADD governorate LABELS
                          lat=centroids$lat, 
                          lng=centroids$lon, 
                          label=as.character(centroids$admin1name),
                          labelOptions = leaflet::labelOptions(
                            noHide = TRUE,
                            interactive = FALSE,
                            direction = "bottom",
                            textOnly = TRUE,
                            offset = c(0, -10),
                            opacity = 0.6,
                            style = list(
                              "color"= "black",
                              "font-size" = "13px",
                              "font-family"= "Helvetica",
                              "font-weight"= 600)
                          )) %>%
      addLabelOnlyMarkers(YEMl, lat=YEMl$lat, #Add Yemen label 
                          lng=YEMl$lon, 
                          label=as.character(YEMl$name),
                          labelOptions = leaflet::labelOptions(
                            noHide = TRUE,
                            interactive = FALSE,
                            direction = "bottom",
                            textOnly = TRUE,
                            offset = c(0, -10),
                            opacity = 1,
                            style = list(
                              "color"= "black",
                              "font-size" = "24px",
                              "font-family"= "Helvetica",
                              "font-weight"= 800,
                              "letter-spacing"= "3px")
                          )) %>%
      
      addPolygons(data= dataM,    # add subsetted district shapefiles
                  color = "grey",
                  weight = .4,
                  label= paste(dataM$admin2name," (", pLa, dataM@data[,6],en, ")"),
                  opacity = 1.0,
                  smoothFactor = 0.5,
                  fill = TRUE,
                  fillColor =  ~mypal(dataM@data[,6]), #custom palette
                  fillOpacity = .8,
                  layerId = ~admin2pcod,
                  highlightOptions = highlightOptions(color = "black", weight = 2,
                                                      bringToFront = TRUE, sendToBack = FALSE),
                  popup = paste0(dataM$admin2name, "<br>",'<h7 style="color:black;">',
                                 pLa, "<b>", dataM@data[,6],en, "</b>", '</h7>'),
      ) %>%
      addPolylines(data = Admin1, #add governorate lines for reference
                   weight= 2,
                   color = "black",
                   fill=FALSE,
                   fillOpacity = 0,
                   opacity = 0.6 )
    
    map1 %>% clearControls()
    
    map1 %>% addLegend("topleft", pal = mypal, values = dataM@data[,6], #update legend to reflect changes in selected district/variable shown
                       labFormat=labelFormat(suffix=unitA),
                       title = "Legend",
                       opacity = 0.6)
    
    
  })#end of MAP
  
  #_________________________create reactive objects for use in the chart___________________
  clicked_state<- eventReactive(input$map1_shape_click,{ #capture ID of clicked district
    return(input$map1_shape_click$id)
  })
  
  state_data <- reactive({ #subset JMMI data table based on clicked state
    dist_dat<-Admin2table[Admin2table$district_ID==clicked_state(),] #strangely reactive objects are stored as functions
    dist_dat
  })
  
 
  chartData1<-reactive({  #subset JMMI data table based on variable of interest (soap, water etc)
    
    if (input$variable1 == "exchange_rates"){
      r<-state_data()[,c(1:5,14,15)]
      colnames(r)<-c("date","government_name","government_ID","district_name","district_ID","variableSEL","date2")
    }
    
    if (input$variable1 == "petrol"){
      r<-state_data()[,c(1:5,6,15)]
      colnames(r)<-c("date","government_name","government_ID","district_name","district_ID","variableSEL","date2")
    }
    
    if (input$variable1 == "diesel"){
      r<-state_data()[,c(1:5,7,15)]
      colnames(r)<-c("date","government_name","government_ID","district_name","district_ID","variableSEL","date2")
    }
    
    if (input$variable1 == "bottled_water"){
      r<-state_data()[,c(1:5,8,15)]
      colnames(r)<-c("date","government_name","government_ID","district_name","district_ID","variableSEL","date2")
    }
    
    if (input$variable1 == "treated_water"){
      r<-state_data()[,c(1:5,9,15)]
      colnames(r)<-c("date","government_name","government_ID","district_name","district_ID","variableSEL","date2")
    }
    
    if (input$variable1 == "soap"){
      r<-state_data()[,c(1:5,10,15)]
      colnames(r)<-c("date","government_name","government_ID","district_name","district_ID","variableSEL","date2")
    }
    
    if (input$variable1 == "laundry_powder"){
      r<-state_data()[,c(1:5,11,15)]
      colnames(r)<-c("date","government_name","government_ID","district_name","district_ID","variableSEL","date2")
    }
    
    if (input$variable1 == "sanitary_napkins"){
      r<-state_data()[,c(1:5,12,15)]
      colnames(r)<-c("date","government_name","government_ID","district_name","district_ID","variableSEL","date2")
    }
    
    if (input$variable1 == "cost_cubic_meter"){
      r<-state_data()[,c(1:5,13,15)]
      colnames(r)<-c("date","government_name","government_ID","district_name","district_ID","variableSEL","date2")
    }
    
    r
  })

  chartNAME<-reactive({ #define element to be used as title for selected variable
    
    if (input$variable1 == "exchange_rates"){
      y="Exchange Rate"
    }
    
    if (input$variable1 == "petrol"){
      y= "Petrol Price"
    }
    
    if (input$variable1 == "diesel"){
      y= "Diesel Price"
    }
    
    if (input$variable1 == "bottled_water"){
      y= "Bottled Water Price"
    }
    
    if (input$variable1 == "treated_water"){
      y= "Treated Water Price"
    }
    
    if (input$variable1 == "soap"){
      y="Soap Price"
    }
    
    if (input$variable1 == "laundry_powder"){
      y= "Laundry Powder Price"
    }
    
    if (input$variable1 == "sanitary_napkins"){
      y= "Sanitary Napkins Price"
    }
    
    if (input$variable1 == "cost_cubic_meter"){
      y= "Cost of Cubic M"
    }
    
    y
  })
  
  #_________________________Create highcharter element which uses dataset filtered by user inputs___________________
  output$hcontainer <- renderHighchart({
    event <- (input$map1_shape_click) #Critical Line!!!
    
    validate(need(event$id != "",
                  "Please click on a district to display its history."))

    ChartDat<-chartData1() #define filtered table that is reactive element chartData1
    
    chosenD<- paste0(ChartDat[1,2],", ",ChartDat[1,4]) #TITLE FOR CHART (governorate and district name)
    
    highchart()%>% #high chart
      hc_xAxis(type = "datetime", dateTimeLabelFormats = list(day = '%b %Y')) %>%
      hc_add_series(ChartDat, "line", hcaes(date2,variableSEL ), color="#4F4E51", name=chartNAME())%>%

      hc_yAxis(title=list(text=chartNAME()), opposite = FALSE) %>%
      hc_title(text=chosenD)%>%
      hc_add_theme(hc_theme_gridlight())%>%
      hc_plotOptions(line = list(
        lineWidth=1.5,
        dataLabels = list(enabled = FALSE)))
    
  })
  output$text1 <- renderUI({ #customised text elements
    HTML(paste("Contact:  yemen@reach-initiative.org",
               "Coordinate System:  WGS 1984",
               "Administrative boundaries:  OCHA",
               "R Mapping Packages:  leaflet, shiny, highcharter",
               sep="<br/>"), '<style type="text/css"> .shiny-html-output { font-size: 11px; line-height: 12px;
         font-family: Helvetica} </style>')
  })
  #
  output$text2 <- renderUI({
    HTML(paste("<i>Note: Data, designations and boundaries contained on
               this map are not warranted to error-free and do not
               imply acceptance by the REACH partners, associated
               donors mentioned on this map</i>",
               sep="<br/>"), '<style type="text/css"> .shiny-html-output { font-size: 11px; line-height: 11px;
         font-family: Helvetica} </style>')
  })
  output$text3 <- renderText({
    paste(chartNAME(), " ", "Index")
  })


  #
  
}



#FRoM ONLINE https://github.com/ua-snap/shiny-apps/blob/master/cc4liteFinal/server.R